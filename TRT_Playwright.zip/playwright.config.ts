import devices from '@playwright/test'
import type { PlaywrightTestConfig } from '@playwright/test';
require('dotenv').config()

const config: PlaywrightTestConfig = {
  testDir: './tests',
  timeout: 0,
  expect: {
    timeout: 0,
  },
  fullyParallel: true,
  workers: 4,
  retries: 0,
  maxFailures: process.env.CI ? 10 : 2,
  use: {
    actionTimeout: 0 * 1000,
    navigationTimeout: 0 * 1000,
    trace: 'on',
    screenshot: 'only-on-failure',
    video: 'on',
  },
  reporter: [['html']],
  projects: [
    {
      name: 'daily',
      use: {
        ...devices['Desktop Chrome'],
        baseURL: process.env.DAILY_URL,
        storageState: 'dailyState.json',
      },
    },
    {
      name: 'staging',
      use: {
        ...devices['Desktop Chrome'],
        baseURL: process.env.STG_URL,
        storageState: 'stgState.json',
      },
    },
  ],
  outputDir: 'test-results/',
};

export default config;