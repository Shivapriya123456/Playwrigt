// import test, { describe, step } from '@utils/fixtures';
// import Base from '@utils/base';

// describe("describing", async () => {
//     test('test 1', async ({ page, github }, info) => {
//         await step("Open Github", async () => {
//             await github.openGithub()
//             let ss = await page.screenshot({ fullPage: true });
//             info.attach("Screen", {
//                 contentType: "img/png",
//                 body: ss
//             })
//         })
//         await step("Check if user logged in", async () => {
//             await github.checkIfUserLoggedIn()
//             await page.screenshot({ fullPage: true })
//         })
//     });
// })