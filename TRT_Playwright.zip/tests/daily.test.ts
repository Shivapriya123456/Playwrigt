import Login from '@pages/login.page';
import scenario, { feature, step } from '@utils/fixtures';
import { beforeEach } from '@utils/hooks';
import * as locators from '../src/locators.json'

beforeEach;

feature("registration", async () => {
    scenario(" Register an Eligible User for Onsite Course ", async ({ page, login }) => {
        await step("Go to Admin Course Registration", async () => {
            await page.goto('https://learn.daily.gsbprint.net/#/Learn/');
            await page.waitForTimeout(5000)
        })
        await step("Open TC Admin", async () => {
        })
    })
    scenario("Register an Non-Eligible User for Onsite Course", async ({ page }) => {

    })
})

feature.only("User Should be able to open admin application", async () => {
    scenario("Check admin", async ({ page }) => {
        await step("Go to Admin Course Registration", async () => {
            await page.goto('https://learn.daily.gsbprint.net/#/Learn/Manager/', { waitUntil: "domcontentloaded" });
            // let onsiteCourseRegister = locators.manager.courseCard.replace('courseType', 'Onsite Course').replace('link', 'Register')
            // await page.locator(onsiteCourseRegister).textContent();
        })
        await step("Open TC Admin", async () => {
        })
    })
})

feature("User Should be able to open admin course registration", async () => {
    let user1;
    let user2;
    scenario("Check admin", async ({ page }) => {
        await step("Click on Register for Onsite Course", async () => {

        })
        await step("Select 2 Eligible Users", async () => {
            //mat-list//*[@title="Eligible"]/ancestor::mat-list-item//mat-checkbox
            //mat-list//*[@title="Eligible"]/ancestor::mat-list-item//*[contains(@class, 'user-name')]
            console.log(user1)
        })
        await step("Register Users", async () => {
            //Date-Time 4:34PM Aug 9, 2022
        })
        await step("Open TC Admin Request", async () => {
            //td[contains(@class,'date')]//span[contains(., '17 Aug')]
            //ancestor::tr//span[contains(.,'Guest Onsite')]//ancestor::tr//span[.="Open"]
        })
        await step("Approve the Users", async () => {
            //mat-accordion[contains(.,user1)]//mat-checkbox
        })
    })
})


//