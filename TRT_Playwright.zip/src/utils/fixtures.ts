import { Page, test as baseTest } from '@playwright/test'
import Base from './base';
import Login from '@pages/login.page';

type pages = {
    page: Page,
    login: Login,
};
const scenario = baseTest.extend<pages>({
    page: async ({ baseURL, page, storageState }, use) => {
        await page.goto(baseURL, { waitUntil: 'commit' });
        await new Login(page).signInIfNot();
        await page.context().storageState({ path: storageState as string });
        await use(page);
    },
    login: async ({ page }, use) => {
        await use(new Login(page));
    },
});

export default scenario;
export const expect = scenario.expect;
export const step = scenario.step;
export const feature = scenario.describe;
export const beforeEach = scenario.beforeEach
export const afterEach = scenario.afterEach