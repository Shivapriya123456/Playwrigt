import { Page } from '@playwright/test'

export default class Base {

    static page: Page = null;
    static ENV: string
    static URL: string
    static USER_NAME: string;
    static PASSWORD: string;

    constructor(public page: Page) {
        this.page = page
        Base.ENV = process.argv.at(-1)
        switch (Base.ENV) {
            case 'daily':
                Base.URL = process.env.DAILY_URL;
                Base.USER_NAME = process.env.DAILY_EMAIL;
                Base.PASSWORD = process.env.DAILY_PASSWORD;
                break;
            case 'staging':
                Base.URL = process.env.STG_URL;
                Base.USER_NAME = process.env.STG_EMAIL;
                Base.PASSWORD = process.env.STG_PASSWORD;
                break;
            default: break
        }
    }
    public async waitForAPIResponse(api: string) {
        this.page.waitForResponse(resp => resp.url().includes(api) && resp.status() === 200)
    }
}