import { beforeEach as beforeEachTest, expect } from "@utils/fixtures"

export const beforeEach = beforeEachTest(async ({ page }) => {
    page.on('response', async response => {
        expect.soft(
            response.status() == (401 || 403 || 500 || 504) ?
                `Error At API : ${response.url()}
                 Status Code: ${response.status()}
                 Response Body : ${await response.body()}`
                : false
        ).toBeFalsy()
    });
})