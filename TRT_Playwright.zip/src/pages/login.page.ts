import Base from '@utils/base';
import { Page } from '@playwright/test';
import * as locators from "../locators.json"

export default class Login {
    page: Page;
    constructor(page: Page) {
        this.page = page
    }

    async signInIfNot() {
        try {
            await this.userLoggedIn()
        } catch {
            await this.signIn()
        }
    }

    async signIn() {
        await this.page.click(locators.login.signInBtn)
        await this.page.fill(locators.login.email, Base.USER_NAME)
        await this.page.click(locators.login.nextBtn)
        await this.page.fill(locators.login.password, Base.PASSWORD)
        await this.page.click(locators.login.signInBtn)
        await this.page.waitForSelector(locators.login.learnHat)
    }

    async userLoggedIn() {
        await this.page.locator(locators.login.learnHat).isVisible();
    }
}