package com.trt.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.trt.generics.GenericMethods;
import com.trt.generics.SetUp;

public class Signin extends GenericMethods{

	public String hpPrintOSPage = "HP PrintOS";
	public String hpIdLoginPage = "HPID Login";
	public String employeeLogonPage = "Employee Log on";
	public String printOsHome = "Home (PrintOS)";
	public String learnHome = "Learn";
	
	public Signin(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "btn-signin")
	public WebElement signInBtn;
	
	@FindBy(id = "username")
	public WebElement username;
	
	@FindBy(xpath = "//div[.='NEXT']")
	public WebElement nextBtn;
	
	@FindBy(id = "username")
	public WebElement logonEmail;
	
	@FindBy(id = "password")
	public WebElement password;

	@FindBy(xpath = "//input[@type='submit']")
	public WebElement logon;
	
	@FindBy(xpath = "//button[.='Visit and Learn']")
	public WebElement visitAndLearnBtn;
	
	public void signIn() throws InterruptedException{
		driver.get(SetUp.Url);
		pageToLoad(hpPrintOSPage);
		click(signInBtn);
		waitFor(username);
		pageToLoad(hpIdLoginPage);
		type(username, "shanmuka.chandra.teja.anem@hp.com");
		click(nextBtn);
		waitFor(password);
		pageToLoad(employeeLogonPage);
		type(password, "Mar@2021");
		type(logonEmail, "shanmuka.chandra.teja.anem@hp.com");
		click(logon);
		waitFor(visitAndLearnBtn);
		pageToLoad(printOsHome);
		click(visitAndLearnBtn);
		waitInSeconds(3);
		pageToLoad(learnHome);
	}
	
}
