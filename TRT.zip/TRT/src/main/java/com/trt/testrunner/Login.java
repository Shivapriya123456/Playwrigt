package com.trt.testrunner;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.trt.generics.GenericMethods;
import com.trt.generics.SetUp;

import cucumber.api.CucumberOptions;
import io.github.bonigarcia.wdm.WebDriverManager;

@CucumberOptions(
		features = "src/main/java/com/trt/features/login.feature", 
		glue = { "com.trt.stepDefinitions" }, 
		dryRun = false, 
		monochrome = true, 
		strict= false,
		plugin = { "pretty",
				"html:cucumber-reports/default-address",
				"rerun:target/cucumber-reports/rerun.txt" })
public class Login extends GenericMethods{

	@BeforeTest
	private void openBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get(SetUp.Url);
	}
	
	@AfterTest
	private void closeBrowser() {
//		driver.quit();
	}
}
