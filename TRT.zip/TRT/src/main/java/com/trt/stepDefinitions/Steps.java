package com.trt.stepDefinitions;

import com.trt.generics.GenericMethods;
import com.trt.generics.SetUp;
import com.trt.pages.Signin;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps extends GenericMethods {

	Signin signIn = new Signin(driver);

	@Given("^Browser is opened$")
	public void browser_is_opened() {
		driver.getTitle();
	}

	@When("^I enter URL$")
	public void i_enter_URL() {
		driver.get(SetUp.Url);
	}

	@Then("^Print OS page should be loaded$")
	public void print_OS_page_should_be_loaded() {
		pageToLoad(signIn.hpPrintOSPage);
	}

	@When("^I click on Signin$")
	public void i_click_on_Signin() {
		click(signIn.signInBtn);
	}

	@Then("^Sign in with your HP account page should be loaded$")
	public void sign_in_with_your_HP_account_page_should_be_loaded() {
		waitFor(signIn.username);
		pageToLoad(signIn.hpIdLoginPage);
	}

	@When("^I enter the Username/Email and click on Next$")
	public void i_enter_the_Username_Email_and_click_on_Next() {
		type(signIn.username, "shanmuka.chandra.teja.anem@hp.com");
		click(signIn.nextBtn);
	}

	@Then("^Employee-Logon page should be loaded$")
	public void employee_Logon_page_should_be_loaded() {
		waitFor(signIn.password);
		pageToLoad(signIn.employeeLogonPage);
	}

	@When("^I enter valid credentials and click on Login$")
	public void i_enter_valid_credentials_and_click_on_Login() {
		type(signIn.password, "Mar@2021");
		type(signIn.logonEmail, "shanmuka.chandra.teja.anem@hp.com");
		click(signIn.logon);
	}

	@Then("^Home page is loaded$")
	public void home_page_is_loaded() {
		waitFor(signIn.visitAndLearnBtn);
		pageToLoad(signIn.printOsHome);
	}

	@When("^I click on Visit and Learn button$")
	public void i_click_on_Visit_and_Learn_button() {
		click(signIn.visitAndLearnBtn);
	}

	@Then("^My Team page should be loaded$")
	public void my_Team_page_should_be_loaded() throws InterruptedException {
		waitInSeconds(3);
		pageToLoad(signIn.learnHome);
	}
}
