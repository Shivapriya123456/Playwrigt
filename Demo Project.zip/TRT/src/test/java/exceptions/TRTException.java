package exceptions;

public class TRTException extends Exception {

	private static final long serialVersionUID = 1L;

	public TRTException(String string) {
		super(string);
	}
}