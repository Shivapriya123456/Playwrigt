package exceptions;

import org.openqa.selenium.WebElement;

public class NoSuchElementException extends Throwable {

	private static final long serialVersionUID = 1L;

	public NoSuchElementException(WebElement element) {
		super("Waited for 10 seconds but "+ element.getClass().getName() + " is not found");
	}
}
