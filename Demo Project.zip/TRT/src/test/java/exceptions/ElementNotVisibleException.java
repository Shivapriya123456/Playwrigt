package exceptions;

import org.openqa.selenium.WebElement;

public class ElementNotVisibleException extends Throwable {

	private static final long serialVersionUID = 1L;

	public ElementNotVisibleException(WebElement element) {
		super(element.toString() + " is not Visible");
	}
}
