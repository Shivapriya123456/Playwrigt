package exceptions;

import org.openqa.selenium.WebElement;

public class ElementNotInteractableException extends Throwable {

	private static final long serialVersionUID = 1L;

	public ElementNotInteractableException(WebElement element) {
		super(element.getText() + " is not Clickable");
	}
}
