package exceptions;

public class TitleNotMatchedException extends Exception {

	private static final long serialVersionUID = 1L;

	public TitleNotMatchedException(String expectedTitle, String actualTitle) {
		super("Expected Title is " + expectedTitle + " but found "+actualTitle);
	}
}
