package stepDefinitions;

import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;
import io.cucumber.java.Status;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utilities.GenericMethods;

public class Hooks extends GenericMethods {
  Scenario scenario;

  @AfterStep
  public void screenShot(Scenario scenario) {
    if (!(scenario.getStatus() == Status.PASSED)) {
      byte[] screenShot =
        ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
      scenario.attach(screenShot, "image/png", scenario.getName());
    }
  }
}
