package stepDefinitions;

import com.trt.pages.Google;

import exceptions.TitleNotMatchedException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utilities.GenericMethods;

public class GoogleSteps extends GenericMethods {

    Google google = new Google(driver);

    @Given("I am on Google Application")
    public void I_am_on_Google_Application() {
    	System.out.println("Hiii");
        google.openGoogle();
    }

    @When("User enters the search keyword {string}")
    public void User_enters_the_search_keyword(String value) {
        google.search(value);
    }

    @Then("User should get the search results")
    public void User_should_get_the_search_results() throws TitleNotMatchedException {
    	pageToLoad("ajsnbfkjsdab");
    }
-
}

