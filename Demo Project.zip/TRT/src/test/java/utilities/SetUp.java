package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author Anem Shanmuka Chandra Teja
 */
public class SetUp extends AbstractTestNGCucumberTests{

	public static String browser = "Chrome";
	public static final String parameters = "src/test/resources/params.properties";
	
	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Actions actions;

	static {
		WebDriverManager.chromedriver().setup();
	}

	// Pages Expected Title
	public static String hpPrintOSPage = "HP PrintOS";
	public static String hpIdLoginPage = "HPID Login";
	public static String employeeLogonPage = "Employee Log on";
	public static String printOsHome = "Home (PrintOS)";
	public static String learnHome = "Learn";
}
