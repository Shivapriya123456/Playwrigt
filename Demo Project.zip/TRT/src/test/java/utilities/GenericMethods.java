package utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import exceptions.NoSuchElementException;
import exceptions.TitleNotMatchedException;

/**
 * @author Anem Shanmuka Chandra Teja
 * 
 *         Super Class to TestRunner Classes
 */
public class GenericMethods extends SetUp {

	public String getProperty(String elementkey) {
		String value = null;
		try {
			Reader file = new FileReader(parameters);
			Properties props = new Properties();
			props.load(file);
			value = props.getProperty(elementkey);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return value;
	}

	public String getEmail() {
		return getProperty("Email");
	}

	public String getPassword() {
		return getProperty("Password");
	}

	public String getURL() {
		return getProperty("URL");
	}

	/**
	 * Retries with try/catch for element's visibility
	 * 
	 * @param driver
	 * @param element
	 * @return
	 * @return
	 * @throws NoSuchElementException
	 * @throws exceptions.ElementNotVisibleException
	 * @throws exceptions.ElementNotVisibleException
	 */
	public WebElement waitFor(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(element)));
			System.out.println("refreshed and waited for " + element);
		}
		/*
		 * catch (ElementNotVisibleException e) { throw new
		 * exceptions.ElementNotVisibleException(element); } catch (TimeoutException |
		 * org.openqa.selenium.NoSuchElementException e) { throw new
		 * NoSuchElementException(element); }
		 */
		return element;
	}

	public WebElement moveTo(WebElement element) {
		waitFor(element);
		actions.moveToElement(element).perform();
		return element;
	}

	public void click(WebElement element) {
		try {
			moveTo(element).click();
		} catch (ElementNotInteractableException e) {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
		}
	}

	/**
	 * Enters a value into a specified text field only if it is found
	 * 
	 * @param driver
	 * @param actions
	 * @param element
	 * @param value
	 */
	public void type(WebElement element, String value) {
		moveTo(element).clear();
		element.sendKeys(value);
	}

	public void typeFilePathToUpload(String path) throws AWTException {

		StringSelection stringSelection = new StringSelection(path);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER);
	}

	public void waitInSeconds(int i) {
		try {
			Thread.sleep(i * 1000);
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void zoomOut() throws AWTException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_SUBTRACT);
		robot.keyRelease(KeyEvent.VK_SUBTRACT);
		robot.keyPress(KeyEvent.VK_SUBTRACT);
		robot.keyRelease(KeyEvent.VK_SUBTRACT);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	/**
	 * To validate if expected page is loaded or not
	 * 
	 * @param driver
	 * @param expectedTitle
	 * @throws TitleNotMatchedException 
	 */
	public void pageToLoad(String expectedTitle) throws TitleNotMatchedException {
		try {
			wait.until(ExpectedConditions.titleIs(expectedTitle));
		} catch (Exception e) {
			String actualTitle = driver.getTitle();
			throw new TitleNotMatchedException(expectedTitle, actualTitle);
		}
	}
}
