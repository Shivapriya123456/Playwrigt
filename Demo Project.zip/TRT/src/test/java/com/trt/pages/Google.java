package com.trt.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.GenericMethods;

public class Google extends GenericMethods{
    public Google(WebDriver driver){
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[@title='Search']")
    private WebElement search;

    public void openGoogle(){
        driver.get(getURL());
    }

    public void search(String value){
        type(search, value);
    }
}
