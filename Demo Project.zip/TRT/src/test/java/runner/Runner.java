package runner;

import io.cucumber.testng.CucumberOptions;
import java.time.Duration;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import utilities.GenericMethods;
import utilities.SetUp;

@CucumberOptions(
  features = "src/test/resources/features/google.feature",
  tags = ("@Google"),
  glue = { "stepDefinitions" },
  dryRun = false,
  monochrome = true,
  plugin = {
    "progress",
    "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
    "rerun:target/cucumber-reports/rerun.txt",
  }
)

public class Runner extends GenericMethods {
	@BeforeTest
	public void browser_is_opened() {
		SetUp.driver = new ChromeDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		actions = new Actions(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	@AfterTest
	public void closeBrowser() {
		driver.quit();
	}
}
