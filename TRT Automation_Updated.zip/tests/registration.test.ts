import scenario, { feature, step } from '@utils/fixtures';
import { beforeEach } from '@utils/hooks';
import { UserType, CourseType, PaymentType } from '@utils/types';
beforeEach;

let testData: Array<{ userType: UserType, courseType: CourseType, paymentType: PaymentType }> = [
    {
        userType: "Eligible",
        courseType: "ILT",
        paymentType: "Entitlement",
    },
    {
        userType: "Non-eligible",
        courseType: "Operator Onsite",
        paymentType: "Entitlement"
    },
    {
        userType: "Non-eligible",
        courseType: "Host Onsite",
        paymentType: "PO"
    }
]

testData.forEach(data => {
    feature("Admin @Registration", async () => {
        scenario.only(`Register ${data.userType} User with ${data.paymentType} from Admin Course Registration Page`, async ({ page, myTeam, sessions }) => {
            await step(`Given I'm on Course Sessions Page`, async () => {
                await sessions.openCourseSessionsPage();
            })
            await step(`When I click on Not Started Session of ${data.courseType} Course`, async () => {
                await page.pause()
                await sessions.openSession({ id: 23456, courseType: data.courseType, status: 'Not Started' })
            })
            await step(`Then Admin Course Registration page should be displayed`, async () => { })
            await step(`When I select an Organization and click on Register Button`, async () => { })
            await step(`Then Course Registration Pop-Up should be displayed`, async () => { })
            await step(`When I select ${data.userType} User(s)`, async () => { })
            await step(`And Select ${data.paymentType} (for OST if required)`, async () => { })
            await step(`And click on Register Button`, async () => { })
            await step(`And Accept the Terms & Conditions if displayed`, async () => { })
            await step(`And Close Registration Complete`, async () => { })
            await step(`And Close Registration Survey Pop-Up`, async () => { })
            await step(`Then The User should be added to the Registered Users List`, async () => { })
        })
    })
})