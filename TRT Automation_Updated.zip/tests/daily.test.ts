import scenario, { feature, step } from '@utils/fixtures';
import { beforeEach } from '@utils/hooks';
import Base from '@utils/base';

beforeEach;

feature("User Should be able to open admin application", async () => {
    scenario("Check admin", async ({ page, myTeam }) => {
        await step("Go to Admin Course Registration", async () => {
            await page.goto('/#/Learn/Manager/ManageEntitlement');
            await myTeam.getResponse({
                URL_Text: 'GetAdminCourseRequest',
                Parameter: 'id', SearchValue: '215'
            })
            await myTeam.getResponse({
                URL_Text: 'GetEnableDesableCovid',
                Parameter: 'isCovidWindow', SearchValue: false
            })
            await myTeam.clickOn('Entitled', 'Register')
            await myTeam.selectUser('Eligible')
            await myTeam.clickButton('Skip Survey ')
            // await page.locator(onsiteCourseRegister).textContent();
        })
        await step("2", async () => {

        })
    })
})

feature("User Should be able to open admin course registration", async () => {
    let user1;
    let user2;
    scenario("Check admin", async ({ page }) => {
        await step("Click on Register for Onsite Course", async () => {

        })
        await step("Select 2 Eligible Users", async () => {
            //mat-list//*[@title="Eligible"]/ancestor::mat-list-item//mat-checkbox
            //mat-list//*[@title="Eligible"]/ancestor::mat-list-item//*[contains(@class, 'user-name')]
            console.log(user1)
        })
        await step("Register Users", async () => {
            //Date-Time 4:34PM Aug 9, 2022
        })
        await step("Open TC Admin Request", async () => {
            //td[contains(@class,'date')]//span[contains(., '17 Aug')]
            //ancestor::tr//span[contains(.,'Guest Onsite')]//ancestor::tr//span[.="Open"]
        })
        await step("Approve the Users", async () => {
            //mat-accordion[contains(.,user1)]//mat-checkbox
        })
    })
})


//