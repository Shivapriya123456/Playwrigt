import { Page, test as baseTest } from '@playwright/test'
import MyTeam from '@pages/MyTeam.page';
import CourseSessions from '@pages/CourseSessions.page';

type pages = {
    myTeam: MyTeam,
    sessions: CourseSessions
};

const scenario = baseTest.extend<pages>({
    page: async ({ baseURL, page }, use) => {
        await page.goto(baseURL);
        await use(page);
    },
    myTeam: async ({ page }, use) => {
        await use(new MyTeam(page));
    },
    sessions: async ({ page }, use) => {
        await use(new CourseSessions(page));
    }
});

export default scenario;
export const expect = scenario.expect;
export const step = scenario.step;
export const feature = scenario.describe;
export const beforeEach = scenario.beforeEach
export const afterEach = scenario.afterEach
export const beforeAll = scenario.beforeAll