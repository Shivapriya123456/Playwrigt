import { Page } from '@playwright/test'
require('dotenv').config()
import * as locators from '../locators.json'
import moment from 'moment'

type ButtonTexts = "Cancel" | "Register" | "OK" | "X" | "Skip Survey "
type CourseTypeNames = "Operator Onsite" | "Host Onsite"

type APIResponse = {
    URL_Text: string;
    Parameter: string;
    SearchValue?: any
}
export default class Base {

    public static page: Page = null;
    public static ENV = process.argv.at(-1);
    public static URL = Base.ENV == 'daily' ? process.env.DAILY_URL : process.env.STG_URL
    public static USERNAME = Base.ENV == 'daily' ? process.env.DAILY_EMAIL : process.env.STG_EMAIL;
    public static PASSWORD = Base.ENV == 'daily' ? process.env.DAILY_PASSWORD : process.env.STG_PASSWORD
    public static locators = locators
    constructor(public page: Page) {
        this.page = page
    }

    public dynamicXpath(dynamicLocator: string, ...replaceWith: any[]): string {
        for (let idx = 0; idx < replaceWith.length; idx++) {
            dynamicLocator = dynamicLocator.replace('replace', replaceWith[idx])
        }
        console.log(dynamicLocator)
        return dynamicLocator
    }

    public static xpathText(type: "contains" | "notContains" | "inDiv" | "inSpan", text: string) {
        let { contains, notContains, textInDiv, textInSpan } = locators.generic
        switch (type) {
            case "contains":
                return contains.replace('text', text)
            case "notContains":
                return notContains.replace('text', text)
            case "inDiv":
                return textInDiv.replace('text', text)
            case "inSpan":
                return textInSpan.replace('text', text)
        }
    }

    public text(text: string) {
        return "text=" + text
    }

    public async clickButton(buttonName: ButtonTexts) {
        // await this.page.click("text=" + button)
        let xpath = "text=" + buttonName
        console.log(xpath)
    }
    public getTime() {
        let date = moment().locale('en-in').format('lll')
        console.log(date)
    }

    public rowsWithText(params: Object) {
        let row = "tr", hasText = "", finalLocator: string;
        for (const key in params) {
            hasText += `:has-text('${params[key]}')`
        }
        finalLocator = row + hasText
        return finalLocator
    }

    public async waitForAPIResponse(api: string) {
        await this.page.waitForResponse(resp => resp.url().includes(api) && resp.status() === 200)
    }
    public async getResponse(api: APIResponse) {
        let response = await this.page.waitForResponse(resp => resp.url().includes(api.URL_Text))
        let responseBody: Array<Object> = await response.json()
        responseBody = Array.isArray(responseBody) ? responseBody : [responseBody]
        let value: any
        if (api.SearchValue) {
            value = responseBody.find(x => x[api.Parameter] == api.SearchValue)
            console.log(value)
        } else {
            console.log(responseBody)
        }
    }
}