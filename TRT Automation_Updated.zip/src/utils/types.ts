export type CourseType = "Host Onsite" | "Operator Onsite" | "ILT"
export type LinkType = "Session Options" | "Info" | "Register"
export type UserType = "Eligible" | "Non-eligible" | "Registered"
export type PaymentType = "Entitlement" | "PO"
export type StatusType = "Not Started" | "On going" | "Finished" | "Cancelled"
export type RequestStatusType = "Closed" | "Open" | "Partially Approved" | "PO Pending" | "PO Uploaded"
export type SessionType = {
    id?: number,
    courseType?: CourseType,
    status: StatusType,
}
export type CourseRequestType = {
    id?: number,
    courseType?: CourseType,
    status: RequestStatusType,
}
export type registrationType = {
    CourseType
}