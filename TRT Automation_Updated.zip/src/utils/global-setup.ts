import Login from '@pages/login.page';
import { chromium, FullConfig, Page } from '@playwright/test'
import Base from '@utils/base';

async function globalSetup(config: FullConfig) {
    const { baseURL, storageState } = config.projects.find(project => project.name == process.argv.at(-1)).use
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({ storageState });
    await context.addCookies([{
        name: 'Indigo-SmS-Auth-Token',
        value: '9m478eqv4929b8pjuld5ptfv6j', //'44afr4bqfb5dn8hfgmmq452slu', //
        url: baseURL!
    }]);
    const page: Page = await context.newPage();
    new Login(page).signInIfNot();
    await page.context().storageState({ path: storageState as string });
    await browser.close()
}

export default globalSetup;