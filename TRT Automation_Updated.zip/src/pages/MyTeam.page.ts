import { Page } from '@playwright/test';
import Base from '@utils/base';
import { CourseType, LinkType, UserType } from '@utils/types';

export default class MyTeam extends Base {
    constructor(page: Page) {
        super(page)
    }

    async openMyTeam() {
        await this.page.goto('/#/Learn/Manager/');
    }

    async clickOn(courseType: CourseType, link: LinkType) {
        const { courseCard } = Base.locators.myTeam;
        let courseEle = courseCard.replace('courseType', courseType).replace('link', link)
        console.log(courseEle)
        // await this.page.click(element)
    }

    async selectUser(userType: UserType) {
        const { user, userCheckbox, selectedUserNames } = Base.locators.registrationPopup;
        const userList = user.replace('userType', userType);
        let userCheckboxes = userList + userCheckbox
        console.log(userCheckboxes)
    }
}