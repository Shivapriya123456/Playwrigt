import Base from '@utils/base';
import { Page } from '@playwright/test';
import * as locators from "../locators.json"

export default class Login extends Base {
    page: Page;
    constructor(page: Page) {
        super(page)
    }

    async signInIfNot() {
        try {
            await this.page.goto('/', { waitUntil: "domcontentloaded" });
            await this.userLoggedIn()
            await this.signIn()
        } catch { }
    }

    async signIn() {
        await this.page.click(locators.login.signInBtn)
        await this.page.fill(locators.login.email, Base.USERNAME)
        await this.page.click(locators.login.nextBtn)
        await this.page.fill(locators.login.password, Base.PASSWORD)
        await this.page.click(locators.login.signInBtn)
        await this.page.waitForSelector(locators.login.learnHat)
    }

    async userLoggedIn() {
        console.log(Base.USERNAME)
        console.log(Base.PASSWORD)
        await this.page.locator(locators.login.learnHat).isHidden();
    }
}