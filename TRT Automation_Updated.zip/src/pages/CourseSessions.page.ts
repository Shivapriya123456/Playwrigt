// "//tbody/tr[not(contains(.,'Operator Onsite')) and not(contains(.,'Host Onsite'))]//span[.='Not Started']
import Base from './../utils/base';
import { Page } from '@playwright/test';
import { expect } from '@utils/fixtures';
import { SessionType } from '@utils/types';

export default class CourseSessions extends Base {
    constructor(page: Page) {
        super(page)
    }

    async openCourseSessionsPage() {
        await this.page.goto('/#/Learn/Manager/ManageEntitlement', { waitUntil: 'load' });
        await this.page.click('text=Course Sessions', { timeout: 120 * 1000 });
        await this.page.waitForResponse(/CourseSessionData/);
    }

    async getSessionWith(session: SessionType) {
        let sessionLocator = ''
        if (session.courseType != 'ILT') {
            sessionLocator = this.rowsWithText(session)
        } else {
            sessionLocator = "//tbody/tr[not(contains(.,'Onsite')) and not(contains(.,'WEBINAR'))]"
        }
        await expect(this.page.locator(sessionLocator).first()).toBeVisible()
        return sessionLocator
    }

    async openSession(session: SessionType) {
        try {
            let sessionLocators = await this.getSessionWith(session)
            let sessionChildLocators = session.courseType != "ILT" ? sessionLocators + ">>span" : sessionLocators + "//span"
            let sessionStatus = await this.page.locator(sessionChildLocators).nth(-3).textContent() //To get status
            await this.page.locator(sessionChildLocators).nth(-3).click() //To click on status
        } catch (error) {
            new Error(session.courseType + "is not found")
        }
    }
}