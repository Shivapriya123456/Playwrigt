import devices from '@playwright/test'
import type { PlaywrightTestConfig } from '@playwright/test';
require('dotenv').config()

const config: PlaywrightTestConfig = {
  testDir: './tests',
  timeout: 0,
  expect: {
    timeout: 10 * 1000,
  },
  fullyParallel: true,
  workers: 4,
  retries: 0,
  maxFailures: process.env.CI ? 10 : 2,
  use: {
    actionTimeout: 0 * 1000,
    navigationTimeout: 120 * 1000,
    trace: 'on',
    screenshot: 'only-on-failure',
    video: 'on',
  },
  reporter: [['html']],
  globalSetup: require.resolve('@utils/global-setup.ts'),
  projects: [
    {
      name: 'daily',
      use: {
        ...devices['Desktop Chrome'],
        baseURL: process.env.DAILY_URL,
        storageState: 'dailyState.json',
        headless: true,
        launchOptions: {
          // force GPU hardware acceleration
          // (even in headless mode)
          args: ["--use-gl=egl"]
        }
      },
      expect: { timeout: 20000 },
      grep: /Admin @Registration/,
    },
    {
      name: 'staging',
      use: {
        ...devices['Desktop Chrome'],
        baseURL: process.env.STG_URL,
        storageState: 'stgState.json',
      },
    },
  ],
  outputDir: 'test-results/',
};

export default config;